#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "device_driver.h"

// 다른 C 파일에 정의된 함수 및 전역 데이터 참조 선언
extern void Mode_Aurora_Wave(uint8_t *step);
extern void Mode_Pink_Candle_Flicker(void);
extern void WS2812_Encode(unsigned char *p_rgb, int len);
extern void WS2812_Send(void);
extern int WS2812_Is_Busy(void);
extern unsigned char led[12]; // timer.c 등에 선언된 12바이트(4개 LED x 3채널) 배열

static void Sys_Init(int baud) 
{
    // Cortex-M4 FPU(부동소수점 연산장치) 코프로세서 CP10, CP11에 완전 접근 권한 부여
    SCB->CPACR |= (0x3 << 10*2) | (0x3 << 11*2); 
    
    Clock_Init();     // MCU 메인 클럭(PLL 84MHz 등) 설정
    Uart2_Init(baud); // 디버깅용 시리얼 통신 초기화
    
    // printf 출력이 내부 버퍼에 쌓이지 않고 즉시 UART로 전송되도록 라인 버퍼링 해제
    setvbuf(stdout, NULL, _IONBF, 0); 
    
    LED_Init();       // 보드 상의 기본 GPIO LED 초기화
}

void Main(void)
{
    Sys_Init(115200); // 115200 bps로 초기화
    printf("=== Smart Mood Lamp Project Start ===\n");

    // WS2812B 펄스 출력용 TIM3_CH3(PB0 핀) PWM 기능 초기화
    TIM3_Out_Init();

    uint8_t mode = 0;         // 현재 동작 모드 (0: 오로라, 1: 핑크 불멍)
    uint8_t aurora_step = 0;  // 오로라 모드의 색상 변화 단계 변수
    uint16_t mode_timer = 0;  // 모드 자동 전환용 카운터

    for (;;) 
    {
        // 현재 선택된 모드로 led[12] 색상 배열 데이터 갱신
        if (mode == 0) {
            Mode_Aurora_Wave(&aurora_step);
        } else {
            Mode_Pink_Candle_Flicker();
        }

        // Raw RGB 12바이트 데이터를 96개 PWM Duty 값으로 인코딩 후 송출 시작
        WS2812_Encode(led, 12);
        WS2812_Send();
        while (WS2812_Is_Busy()); // 하드웨어 인터럽트 전송이 완전히 끝날 때까지 대기

        // 약 9초마다 모드 자동 전환 (30ms x 300회 = 9000ms = 9초)
        mode_timer++;
        if (mode_timer > 300) { 
            mode_timer = 0;
            mode = (mode == 0) ? 1 : 0; // 0과 1을 번갈아 토글
            printf("Mode Changed: %d\n", mode);
        }

        // TIM2 타이머를 이용한 30ms 프레임 지연 (애니메이션 속도 조절)
        TIM2_Delay(30);
    }
}