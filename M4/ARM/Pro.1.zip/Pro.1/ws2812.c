#include <stdio.h>         // printf 사용
#include "device_driver.h"
#include "stm32f4xx.h"

// WS2812B 통신 타이밍 관련 하드웨어 설정 상수 (클럭 설정 기준)
#define WS_ARR_BIT   (120 - 1)          // PWM 1주기 타이머 카운트값 (1.25us 펄스 생성)
#define WS_T0H       38                 // 비트 '0'일 때 High 유지 시간 (약 0.4us)
#define WS_T1H       82                 // 비트 '1'일 때 High 유지 시간 (약 0.8us)
#define WS_RESET_N   48                 // Reset 신호 주기 횟수 (48 x 1.25us = 60us 동안 Low)

#define WS_MAX_LED   4                  // 제어할 LED 개수
#define WS_MAX_BIT   (WS_MAX_LED * 24)  // 총 송신 비트 수 (4개 x 24비트 = 96비트)

// 드라이버 내부 상태 관리 정적 변수들
static unsigned short ws_buf[WS_MAX_BIT];        // 96개 비트의 CCR3 Duty 값이 저장될 버퍼
static volatile int ws_idx, ws_total, ws_rst;    // 전송 인덱스 및 리셋 카운터
static volatile int ws_busy;                     // 전송 중 플래그 (1: 전송 중, 0: 완료)
static volatile int ws_pre;                      // 데이터 전송 전 Pre-Reset 카운터


void WS2812_Encode(unsigned char *grb, int nbyte)
{
    int i, b, k = 0;
    for(i = 0; i < nbyte; i++)
    {
        // MSB(최상위 비트)부터 LSB(최하위 비트) 순서로 1비트씩 확인
        for(b = 7; b >= 0; b--)
        {
            // 비트가 1이면 WS_T1H(82), 0이면 WS_T0H(38) 값을 버퍼 배열에 순서대로 기록
            ws_buf[k++] = (grb[i] & (1 << b)) ? WS_T1H : WS_T0H;
        }
    }
    ws_total = k; // 총 전송할 비트 개수 저장 (96개)
}


void WS2812_Send(void)
{
    // 전송 상태 변수 초기화
    ws_idx = 0;
    ws_rst = 0;
    ws_pre = WS_RESET_N; // Pre-Reset (60us) 횟수 설정
    ws_busy = 1;         // 상태를 '전송 중'으로 변경

    TIM3->PSC = 0;           // 분주비 0 (최고 속도 동작)
    TIM3->ARR = WS_ARR_BIT;  // 주기 1.25us 설정

    // 첫 출력을 0(Low)으로 보장하기 위해 PWM Duty 레지스터 초기화                  
    Macro_Set_Bit(TIM3->EGR, 0);        // UG 비트 강제 세트 -> Shadow 레지스터로 0 즉시 반영
    TIM3->CCR3 = 0;                     // Preload 레지스터도 0 처리

    Macro_Clear_Bit(TIM3->SR, 0);       // 타이머 기존 인터럽트 플래그 청소
    NVIC_ClearPendingIRQ(29);           // NVIC 대기 중인 TIM3 인터럽트 청소 (29번 = TIM3_IRQn)
    NVIC_SetPriority(29, 0);            // 최우선 순위(0번) 부여 (타이밍 오차 방지)
    Macro_Set_Bit(TIM3->DIER, 0);       // Update Interrupt Enable (주기마다 인터럽트 발생 허용)
    NVIC_EnableIRQ(29);                 // NVIC 차원에서 TIM3 인터럽트 활성화

    // TIM3 타이머 시작 (ARPE=1, CEN=1)
    TIM3->CR1 = (1<<7) | (0<<4) | (0<<3) | (1<<0);
}

/**
 * @brief  현재 전송이 진행 중인지 여부를 반환
 * @return 1: 전송 중, 0: 전송 완료
 */
int WS2812_Is_Busy(void) { return ws_busy; }

/**
 * @brief  TIM3 타이머 인터럽트 서비스 루틴 (ISR)
 * @note   1.25us 주기로 계속 호출되며, PWM 듀티비(CCR3)를 동적으로 변경함
 */

void TIM3_IRQHandler(void)
{
    Macro_Clear_Bit(TIM3->SR, 0); // 타이머 인터럽트 플래그 클리어

    // 데이터 전송 전 Pre-Reset 신호 출력 (60us 동안 Duty 0 유지)
    if(ws_pre > 0) 
    {
        TIM3->CCR3 = 0;
        ws_pre--;
    }
    // 인코딩된 비트 버퍼(38 또는 82)를 하나씩 CCR3에 적용하여 펄스 변조
    else if(ws_idx < ws_total)
    {
        TIM3->CCR3 = ws_buf[ws_idx++];
    }
    //데이터 전송 완료 후 Post-Reset 신호 출력 (60us 동안 Duty 0 유지하여 Latch)
    else if(ws_rst < WS_RESET_N)
    {
        TIM3->CCR3 = 0;
        ws_rst++;
    }
    // 모든 전송이 완료된 경우 하드웨어 멈춤 처리
    else
    {
        Macro_Clear_Bit(TIM3->CR1, 0);  // TIM3 카운터 정지
        Macro_Clear_Bit(TIM3->DIER, 0); // TIM3 인터럽트 비활성화
        NVIC_DisableIRQ(29);            // NVIC 인터럽트 정지
        ws_busy = 0;                    // Main 루프에 전송 완료 알림 (Busy 해제)
    }
}

/**
 * @brief  디버깅용 버퍼 출력 함수 (UART 모니터로 변환된 24비트 펄스 확인용)
 */
void WS2812_Debug_Print(void)
{
    int i;
    printf("ws_buf: ");
    for(i = 0; i < 24; i++)
        printf("%d ", ws_buf[i]);
    printf("\n");
}